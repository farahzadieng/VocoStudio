from huggingface_hub import snapshot_download
from pathlib import Path


BASE_DIR = Path(__file__).parent / "ClearVoice-Models"


MODELS = {
    "FRCRN_SE_16K": "alibabasglab/FRCRN_SE_16K",
    "MossFormerGAN_SE_16K": "alibabasglab/MossFormerGAN_SE_16K",
    "MossFormer2_SE_48K": "alibabasglab/MossFormer2_SE_48K",
    "MossFormer2_SS_16K": "alibabasglab/MossFormer2_SS_16K",
    "MossFormer2_SR_48K": "alibabasglab/MossFormer2_SR_48K",
    "AV_MossFormer2_TSE_16K": "alibabasglab/AV_MossFormer2_TSE_16K",
}


def download_models():
    BASE_DIR.mkdir(exist_ok=True)

    for name, repo in MODELS.items():
        target = BASE_DIR / name

        print("\n" + "=" * 60)
        print(f"Downloading: {name}")
        print(f"Repository: {repo}")
        print(f"Destination: {target}")
        print("=" * 60)

        snapshot_download(
            repo_id=repo,
            local_dir=str(target),
            local_dir_use_symlinks=False
        )

        print(f"Finished: {name}")


if __name__ == "__main__":
    download_models()
